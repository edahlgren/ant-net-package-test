// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: dataSink.h
//        (part of BeeHive Routing Simulation)
//-------------------------------------------------------------


#ifndef __DATA_SINK_H
#define __DATA_SINK_H

#include <omnetpp.h>
#include "statistics.h"
#include "routingDB.h"

#define INTERVAL 1


class dataSink : public cSimpleModule
{
	cStdDev eePacketDelay;   // End to End Packet Delay 
							//  needs to be accessed from finish() too
	cOutVector cumThroughPut;
	cOutVector packetDelay;
	cStdDev tHops;
	statistics *sPtr;
	routingDB *rDB;

	double cumBitsReceivedValue;
	double intervalBitsReceivedValue;
	int i;
	double sleepTime;
	double interval;
	double lastSimTime;
	double pDelay;
	int numberPackets;

	cMessage *measureThroughPut;
	cMessage *startMeasuring;

	bool debug;
	bool logResults;

	virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void finish();

	public:
		dataSink(const char *name, cModule *parentmodule,unsigned stacksize = 0);
		virtual ~dataSink();
}; 

#endif