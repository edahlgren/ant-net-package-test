// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: ant.h
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#ifndef __ANT_H
#define __ANT_H

#include <omnetpp.h>
#include <vector>
#include <stack>
#include <list>
#include <string>
#include "ant_m.h"
#include "protocolParameters.h"

using namespace std;

#define BYTE 8

class Ant: public Ant_Base
{
	protected:
		vector<int> visitedNodes;
		vector<antStackEntry*> cycleNodes; // this will simulate a stack for ant
		int neighborChosen;
		int sourceModule;

	public:
		Ant(const char* name = NULL);
		Ant(int source, int destination, const char*name = NULL);
		Ant(const Ant& other);
		Ant& operator = (const Ant& other);
		virtual ~Ant();
		virtual cObject *dup() const;

		//visitedNodes--vector

		virtual void setVisitedNodesArraySize(unsigned int size);
		virtual unsigned int getVisitedNodesArraySize() const;
		virtual int getVisitedNodes(unsigned int k) const;
		virtual void setVisitedNodes(unsigned int k, int node);
		virtual void addToVisitedNodes(const int& node);
		virtual bool nodeAlreadyVisited(const int& node);

		// cycleNode List
		virtual void setCycleNodesArraySize(unsigned int size);
		virtual unsigned int getCycleNodesArraySize() const;
		virtual antStackEntry& getCycleNodes(unsigned int k);
		virtual void setCycleNodes(unsigned int k, const antStackEntry& entry);
		virtual void addToCycleNodes(const antStackEntry& entry);
		virtual bool cycleNodeAlreadyVisited(const int& node);
		void deleteCycleNode(const int node);
		double nodeEntryTime(const int node,int myAddress);
		vector<antStackEntry*>::iterator currentNodeIter(const int node);
		vector<antStackEntry*>::iterator destNodeIter();

		int forwardAntSize();
		int backwardAntSize(int size);
		int backwardAntSize();

		
		//get and set methods

		void setNeighborChosen(int neighbor);
		int getNeighborChosen();
		void showVisitedNodeVector();
		void setSourceModule(int module);
		int getSourceModule();
		int getPreviousNode(int node);
		antStackEntry topOfStack();
};


#endif