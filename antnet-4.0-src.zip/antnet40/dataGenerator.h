// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: dataGenerator.h
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#ifndef __DATA_GEN_H
#define __DATA_GEN_H

#include <omnetpp.h>
#include "statistics.h"
#include <map>
#include <vector>

using namespace std;

#define SEND_SCHEDULING_P 10
#define TIME_SMALLEST_UNIT_DOUBLE 0.0001

#define SEND_HOT_SESSION_P 1

#define RANDOMDESTINATION  1
#define PREVIOUSDESTINATION 2
#define TIMEWINDOW 10
#define WINDOW 200

#define BYTE 8

class dataGenerator : public cSimpleModule
{
	Module_Class_Members(dataGenerator, cSimpleModule,0)

	//map<sessionId, pair<dest,restPackets>>
	map<int,pair<int,int> > session;
	int sessionId;

	//pair<dest, timeWindow>
	pair<int, int> destWin;

	int numMessages;
	int myAddress;
	int numStations;
	int packetId;
	double converganceTime;
	double sleepTime;
	double factor;
	
	double length;
	double mpia;
	double msia;
	int i;
	double sessionSize;
	int hotSpot;
	
	double startTime;
	double endTime;
	double hotmpia;

	cMessage *hotSession;

	
	statistics *sPtr;
	char sFileName[100];

	bool debug;
	bool logResults;

	double beginWindow;
	double endWindow;
	bool sleep;


	void creatSession();
	void sendForSession(int id);
	void scheduleSession(int id, cMessage* msg);
	void stopSession(int id, cMessage* msg);
	double messageGenerated;
	virtual void initialize();
	virtual void handleMessage(cMessage *msg);    
    virtual void finish();
	int getRandom(int i);
	int generateDestination(int k);
	void setDestinationSelectionMode();
	void sendHotDestination();
};

#endif