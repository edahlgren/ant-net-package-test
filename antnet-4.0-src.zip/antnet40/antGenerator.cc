// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System,
// Universitaet Dortmund
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: antGenerator.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include <stdio.h>
#include "antGenerator.h"
#include "Messages_m.h"
#include "ant.h"

Define_Module( antGenerator );

antGenerator::antGenerator(const char *name, cModule *parentmodule, unsigned stacksize)
  : cSimpleModule(name, parentmodule,stacksize)
{
	dataPacketSentToDestination = NULL;
	antsGeneratedForEachDestination = NULL;
	antGenerationProbability = NULL;
}

void antGenerator::activity()
{
    int myAddress = par("address");
	numStations = par("numStations");
	cPar& sleepTime = par("sleepTimeAtStart");
    cPar& interArrivalTime = par("iaTime");
	int messageLength = par("messageLength");
	double converganceTime = par("converganceTime");
	int antID = 0;

	totalPacketsSent = 0.0;

	debug = true;
	logResults = par("logResults");

	dataPacketSentToDestination = new double[numStations];
	antGenerationProbability = new float[numStations];
	antsGeneratedForEachDestination = new double[numStations];
	for(int i = 0; i < numStations; i++)
	{
		dataPacketSentToDestination[i] = 0.0;
		antGenerationProbability[i] = 0.0;
		antsGeneratedForEachDestination[i] = 0.0;
	}

	const char *statModulePath = par("statModulePath");
	cModule *tmp1 = simulation.moduleByPath(statModulePath);
	sPtr= check_and_cast<statistics *> (tmp1);

	launchNewAnts = new cMessage("launchNewAnts");

	wait( sleepTime );

	simtime_t antGenInterval = (double) interArrivalTime;
	scheduleAt( simTime() + antGenInterval, launchNewAnts);


	char msgname[70];

	for(;;)
	{

		cMessage *msg = receive();

		if( simTime () < 1500)
		{
			if(dynamic_cast<samplePacket *> (msg) != NULL)
			{
				samplePacket *dPacket = (samplePacket*) msg;
				int destination = dPacket->getDestAddress();
				dataPacketSentToDestination[destination] += 1.0; // fsd
				totalPacketsSent += 1.0; // sum of fsd� where d` represents all destinations
				antGenerationProbability[destination] =
					dataPacketSentToDestination[destination] / totalPacketsSent; //Pd
				delete dPacket;

			}

			else if (msg = launchNewAnts)
			{
				int dest = intuniform(0,numStations-2);
				if(dest >= myAddress) dest++;
				sprintf(msgname, "Ant%d-Source%d-Destination %d", antID++, myAddress, dest);
				Ant *antMsg = new Ant(msgname);
				antMsg->setSourceNode(myAddress);
				antMsg->setTimeAtNextHop(simTime());
				antMsg->setKind( (int) NETLAYER_FORWARD_ANT);
				antMsg->setDestNode(dest);
				antMsg->setLength( BYTE * messageLength);
				antMsg->setTimestamp();
				antMsg->setSourceModule( (int) ANT_GEN);
				if(debug)
				{
					ev << "Ant : \"" << msgname << "\", "
						"length=" << messageLength << "bytes, dest=" << dest << endl;
				}

				send(antMsg, "toAntNest");
				sPtr->incrTotalAntsGenerated();
				antsGeneratedForEachDestination[dest]++;
				antGenInterval = (double) interArrivalTime;
				scheduleAt( simTime() + antGenInterval, launchNewAnts);

			}
		}

		else
		{
			if(dynamic_cast<samplePacket *> (msg) != NULL)
			{
				samplePacket *dPacket = (samplePacket*) msg;
				int destination = dPacket->getDestAddress();
				dataPacketSentToDestination[destination] += 1.0; // fsd
				totalPacketsSent += 1.0; // sum of fsd� where d` represents all destinations
				antGenerationProbability[destination] =
					dataPacketSentToDestination[destination] / totalPacketsSent; //Pd
				delete dPacket;

			}

			else if (msg = launchNewAnts)
			{
				antGenInterval = (double) interArrivalTime;

				double prob = uniform(0.0, 1.0);
				double lowerBound = 0.0;
				double upperBound = 0.0;
				for(int k = 0; k < numStations; k++)
				{
					upperBound += antGenerationProbability[k];
					if ( (prob >= lowerBound && prob <= upperBound) && k != myAddress)
					if ( k != myAddress)
					{
						// select a destinatin according to probabiltiy Pd
						// create Packet

						sprintf(msgname, "Ant%d-Source%d-Destination %d", antID++, myAddress, k);
						Ant *antMsg = new Ant(msgname);
						antMsg->setTimeAtNextHop(simTime());
						antMsg->setSourceNode(myAddress);
						antMsg->setKind( (int) NETLAYER_FORWARD_ANT);
						antMsg->setDestNode(k);
						antMsg->setTimestamp();
						antMsg->setSourceModule( (int) ANT_GEN);
						// send this packet on the gate out that is connected to the router at network layer, that
						// will take the routing decisions

						if(debug)
						{
							ev << "Ant : \"" << msgname << "\", "
								"length=" << messageLength << "bytes, dest=" << k << endl;
						}

						send(antMsg, "toAntNest");
						sPtr->incrTotalAntsGenerated();
						antsGeneratedForEachDestination[k]++;

					}
					lowerBound = upperBound;
				}

				// wait between packet sending. Here we could give different ditributions for
				// packet arrival and then test the impact of load generated by these distributions
				// and study the behavior of routing algorithm on them
				// However here we take interArrivalTime as constant

				antGenInterval = (double) interArrivalTime;
				scheduleAt( simTime() + antGenInterval, launchNewAnts);
			}
		}
	}
}

antGenerator::~antGenerator()
{
	delete[] dataPacketSentToDestination;
	delete[] antsGeneratedForEachDestination;
	delete[] antGenerationProbability;
}

void antGenerator::finish()
{
    ev << "*** Module: " << fullPath() << "***" << endl;
    ev << "Stack allocated:      " << stackSize() << " bytes";
    ev << " (includes " << ev.extraStackForEnvir() << " bytes for environment)" << endl;
    ev << "Stack actually used: " << stackUsage() << " bytes" << endl;
/*	for(int k = 0; k < numStations; k++)
	{
		ev<<"Total Ants Generated for Detination:  " << k <<"  are  "
			<< antsGeneratedForEachDestination[k] << endl;
	}*/
}
