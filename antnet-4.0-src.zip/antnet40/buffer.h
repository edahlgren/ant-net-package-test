// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: buffer.h
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#ifndef __BUFFER_H
#define __BUFFER_H

#include "protocolParameters.h"

class Buffer{

	private:

		int portIndex;//identity
		unsigned int queueSize; // length of queue in number of messages
		int normalQueueCapacity;
		int quickQueueCapacity;
		bool debug;

		vector<cMessage*>* theQueue;//normal buffer
		deque<cMessage*>* theQuickQueue;//quick priority buffer

	public:
		Buffer(int port, unsigned int qSize);
		~Buffer();

		int getPortIndex();
		void setPortIndex(int value);

		virtual int getQuickQueueSize();
		virtual int getNormalQueueSize();

		virtual int getNormalQueueCapacity();
		virtual int getQuickQueueCapacity();


		void clear(int& beeCount, int& dataCount);
		void clear();

		virtual bool empty();
		virtual bool enqueueInNormalQueue(cMessage *p);
		virtual bool enqueueInQuickQueue(cMessage *p);
		virtual cMessage* fetchNextPacketToSend();

};

#endif
