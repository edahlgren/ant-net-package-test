// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: routingTable.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------



#include "routingTable.h"

routingTable::routingTable(const char* name)
{
}

routingTable::~routingTable()
{
}

routingTable::routingTable(const routingTable& rhs)
{
	operator=(rhs);
}

routingTable& routingTable::operator=(const routingTable& rhs)
{
	if(this == &rhs)
	{
		return *this;
	}
	else
	{
		this->rTable = rhs.rTable;
		return *this;
	}
}

double routingTable::getDestViaThisNeighborProb(int dest, int port)
{
	RTEntry key;
	key.neighborPort = port;
	key.destAddress  = dest;

	antRoutingTable::const_iterator I = rTable.find(key);

	if( I != rTable.end() )
	{
		return (*I).second;
	}
	else
	{
		throw new cException("Could not find port %d for dest %d in routing table",port,dest);

	}
}

void routingTable::setDestViaThisNeighborProb(int dest, int port, double prob)
{
	RTEntry key;
	key.neighborPort = port;
	key.destAddress  = dest;
	rTable[key] = prob;
}

void routingTable::printRoutingTable(int router)
{
	char fileName[70];
	sprintf(fileName,"routingTable%d.txt",router);

	ofstream f2(fileName,ios::out);
	string msg;

	msg += "********************\n";
	msg += "    Routing Table   \n";
	msg += "*********************\n";

	antRoutingTable::const_iterator I;
	for(I = rTable.begin(); I != rTable.end(); I++)
	{
		RTEntry k = (*I).first;
		msg += "Probal to destination: ";
		msg +=  itos(k.destAddress);
		msg += "   Via Port: ";
		msg += itos(k.neighborPort);
		msg += " = ";
		msg += ftos((*I).second);
		msg += "\n";
	}
	f2 << msg << endl;
}
