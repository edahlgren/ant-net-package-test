// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: router.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include "router.h"

Define_Module( Router );

Router::Router(const char *name, cModule *parentmodule,unsigned stacksize)
	:cSimpleModule(name, parentmodule, stacksize)
{
	qBuffer = new map<int, Buffer*>();
	neighborPortID = new map<int,pair<int,int>*>();
	msgServiced = new map<int,cMessage*>();
	sendControlOrDataPacket = new map<int,cMessage*>();
	bandWidthPdelay = new map<int,pair<double,double>*>();

	IPAddress = -1;
	contextSwitchTime = 0;
	numNeighbors = 0;
}

Router::~Router()
{

	map<int,pair<int,int>*>::const_iterator P;

	for( P = (*neighborPortID).begin(); P != (*neighborPortID).end(); P++)
	{
		delete (*P).second;
	}

	delete neighborPortID;

	map<int,Buffer*>::const_iterator I;

	for( I = (*qBuffer).begin(); I != (*qBuffer).end(); I++)
	{
		delete (*I).second;
	}

	delete qBuffer;
	delete msgServiced;
	delete sendControlOrDataPacket;

	map<int,pair<double,double>*>::const_iterator N;
	
	for( N = (*bandWidthPdelay).begin(); N != (*bandWidthPdelay).end(); N++)
	{
		delete (*N).second;
	}

	delete bandWidthPdelay;
	delete rTable;
	delete neighborAtIndex;
}

void Router::initialize()
{
	dataRate = par("dataRate"); 
	IPAddress = par("address");

	queueSize= static_cast<int> ( par("queueSize") );
	numNodes = par("numStations");

	startTime = static_cast<double> ( par("startTime") );
	endTime = static_cast<double> ( par("endTime") );
	qWeightFactor = static_cast<double> ( par("qWeightFactor") );
	debug = false;

	logResults = par("logResults");

	const char *statModulePath = par("statModulePath");
	cModule *tmp1 = simulation.moduleByPath(statModulePath);
	sPtr= check_and_cast<statistics *> (tmp1);	

	converganceTime = (double) par("converganceTime");
	probabilisticRouting = par("probabilisticRouting");


	fsm.setName("fsm");

	dataPacketLength = static_cast<int> (gate("fromDataGen")->fromGate()->ownerModule()->par("messageLength"));

	resendAttempts = static_cast<int> ( par("resendAttempts") );

	agentProcTime = static_cast<bool> (par("agentProcTime"));
	contextSwitchTime = static_cast<double>(par("contextSwitchTime"));

	numNeighbors = 0;
	routerDown = false;

	tcb.state = INIT_S;

	buildGateIDToNeighborMap();

	//allocate buffers for each neighbor

	map<int,pair<int,int>*>::const_iterator I;
	
	numNeighbors = (*neighborPortID).size();
	
	neighborAtIndex = new int[numNeighbors];

	int i = 0;
	
	for( I = (*neighborPortID).begin();  I != (*neighborPortID).end(); I++)
	{
		int port = (*I).first;
		neighborAtIndex[i] = (*((*I).second)).second;
		Buffer *tmp = new Buffer(port, queueSize);
		(*qBuffer)[port] = tmp;

		(*sendControlOrDataPacket)[port] = new cMessage("sendControlorDataPacket");
		(*sendControlOrDataPacket)[port]->setKind(TRANSMIT_PACKET + port);
		(*msgServiced)[port] = NULL;
		i++;
	}

	rTable = new routingTable();

	bHelloSize = originalHelloSize * BYTE; 

	hopsLimit =  static_cast<int> (hopsLimitFactor * numNodes);

	startUpMessage = new cMessage("StartUpMessage",START_UP_MESSAGE);
	scheduleAt(0.0 , startUpMessage);

}

void Router::handleMessage(cMessage *msg)
{
	simtime_t time = simTime();

	if( time >= startTime && time < endTime )
	{
		if( !routerDown )
		{
			routerDown = true;
			clearAllBuffersOfRouter();
		}

		if(dynamic_cast<samplePacket *> (msg) != NULL)  
		{
			samplePacket *dPacket = (samplePacket*) msg;
			int destination = dPacket->getDestAddress();

			if(destination == IPAddress)
			{
				sPtr->incrTotalBitsUndeliverable();
				
			}
			else
			{
				int id = msg->arrivalGateId();
				if( id != 1)
				{
					sPtr->incrTotalBitsLost();
				}
				else
				{
					sPtr->incrTotalDownBitsGenerated();
				}
			}
			delete dPacket;

		}
		else if(dynamic_cast<Ant *> (msg) != NULL)
		{
			sPtr->incrTotalAntsDeleted();
			delete msg;
		}
		else if( dynamic_cast<helloPacket*> (msg) != NULL)
		{
			delete msg;
		}

	}
	else 
	{
		routerDown = false;

		FSM_Switch( fsm )
		{
			case FSM_Exit(INIT):
				// switch to send Hello Packet State
				analyzeEvent(msg);
				performExitInitActions(msg);
				break;

			case FSM_Exit(NORMAL):
				analyzeEvent(msg);
				performActionsInNormalState(msg);
				break;

		} 
	}
}


void Router::analyzeEvent(cMessage *msg)
{
	switch(msg->kind())
	{
		case START_UP_MESSAGE:
			tcb.event = START_UP_MESSAGE_EVENT;
			break;

		case NETLAYER_HELLO_PACKET:
			tcb.event = NETLAYER_HELLO_PACKET_EVENT;
			break;
		
		case NETLAYER_HELLO_REPLY_PACKET:
			tcb.event = NETLAYER_HELLO_REPLY_PACKET_EVENT;
			break;

 		case NETLAYER_DATA_PACKET:
			tcb.event = NETLAYER_DATA_PACKET_EVENT;
			break;

		case NETLAYER_BACKWARD_ANT:
			tcb.event = NETLAYER_BACKWARD_ANT_EVENT;
			break;

		case NETLAYER_FORWARD_ANT:
			tcb.event = NETLAYER_FORWARD_ANT_EVENT;
			break;
		
		default:
			if( msg->kind() >= TRANSMIT_PACKET)
			{
				tcb.event = TRANSMIT_PACKET_EVENT;
			}
			else
			{
				throw new cException("Unknown event %s %d in AnyalyzeEvent:", msg->name, msg->kind());
			}
			break;
	}
}

void Router::performExitInitActions(cMessage *msg)
{
	switch(tcb.event)
	{
		case START_UP_MESSAGE_EVENT:
			enqueHelloPacketInBuffers();
			tcb.state = NORMAL_S;
			FSM_Goto(fsm,NORMAL);
			break;

		default:
			if(debug)
			{
				ev << "In INIT state received: " << tcb.event << endl;
				ev << "Ignoring case: not handeled in switch(INIT)";
			}
			break;
	}
}

void Router::performActionsInNormalState(cMessage *msg)
{

	switch(tcb.event)
	{

		case NETLAYER_HELLO_PACKET_EVENT:
			processHelloPacket(dynamic_cast<helloPacket*>(msg));
			break;

		case NETLAYER_HELLO_REPLY_PACKET_EVENT:
			processHelloReplyPacket(dynamic_cast<helloPacket*>(msg));
			delete msg;
			break;

		case NETLAYER_DATA_PACKET_EVENT:
			processDataPacket(dynamic_cast<samplePacket*>(msg));
			break;

		case NETLAYER_FORWARD_ANT_EVENT:
			processForwardAnt((Ant *) msg);
			break;

		case NETLAYER_BACKWARD_ANT_EVENT:
			processBackwardAnt((Ant *) msg);
			break;

		case TRANSMIT_PACKET_EVENT:
			processTransmitPacket(msg);
			break;

		default:
			ev << "In Normal State received: " << tcb.event << endl;
			throw new cException("Unexpected Event: Case Not Handeled");
			break;
	}
}

void Router::enqueHelloPacketInBuffers()
{
	char msgname[70];

	// We need to find out which ports are connected to another Routers 
	// and then send hello message on all of these ports

	map<int,pair<int,int>*>::const_iterator I;

	for( I = (*neighborPortID).begin(); I != (*neighborPortID).end(); I++)
	{
		int port = (*I).first;
		pair<int,int>& thePair = *((*I).second); 
		int neighborAddress = thePair.second;


		sprintf(msgname, "Hello Packet Source%d-Destination %d", IPAddress, neighborAddress);

		helloPacket *hPacket = new helloPacket(msgname);
		hPacket->setSourceAddress(IPAddress);
		hPacket->setLength(bHelloSize);
		hPacket->setKind(static_cast<int> (NETLAYER_HELLO_PACKET) );
		hPacket->setTimestamp(simTime());
		queueManagementForMessage(hPacket,port);
	}
}

void Router::processHelloPacket(helloPacket* msg)
{
	// Find out the port from where this hello packet arrived

	int port = msg->arrivalGateId();
	int sourceAddress = msg->getSourceAddress();

	msg->setNeighborAddress(IPAddress);
	msg->setKind(NETLAYER_HELLO_REPLY_PACKET);

	msg->setTimestamp( simTime() );
	queueManagementForMessage(msg,port);
}

void Router::processHelloReplyPacket(helloPacket* msg)
{
	simtime_t rxTime = simTime();
	simtime_t txTime = msg->getTxTime();
	simtime_t qTime = msg->getQDelayAtNeighbor();

	int messageID = msg->getMessageID();

	int port = msg->arrivalGateId();

	map<int,pair<double,double>*>::const_iterator J = (*bandWidthPdelay).find(port);

	if( J != (*bandWidthPdelay).end() )
	{
		pair<double,double>& thePair = *((*J).second);
		simtime_t transmitTime = static_cast<double> ( msg->length() / thePair.first );

		// Estimate the propagation delay

		double pDelay = ( rxTime - txTime - qTime) / 2.0 - transmitTime;

		(*((*bandWidthPdelay)[port])).second = pDelay;
		if(debug)
		{
			ev<<"Propagation Delay between node: " << IPAddress << "and node: " << msg->getNeighborAddress() <<"    "<<
				pDelay<<endl;
		}
	}
	else
	{
		throw new cException("Received reply from Neighbor: %d(Unknown) ", (*((*neighborPortID)[port])).second);

	}
}

void Router::processForwardAnt(Ant *msg)
{
	findSourceForAnt( msg );

	if( tcb.source == ROUTER)
	{
		send( msg, "toAntNest");
	}

	else if( tcb.source == ANT_NEST)
	{
		// now do the recording keep values by pushing the
		// entrance time and nodeID onto the stack.
		// for quick checking of cycles, we keep another
		// array for the nodes being visited by the ant.

		int neighbor = msg->getNeighborChosen();
		double estimatedEntryTimeToThisNode = msg->getTimeAtNextHop();
		double delay = estimateTimeToNextNode(neighbor);
		msg->setTimeAtNextHop( estimatedEntryTimeToThisNode + delay);
		int index = findInputGateIDForNeighbor(neighbor);
		queueManagementForMessage(msg, index);
	}

	else
	{
		throw new cException("Unknown source for Ant in Router %d",IPAddress);
	}
}

void Router::processBackwardAnt(Ant* msg)
{
	findSourceForAnt( msg );

	if( tcb.source == ROUTER)
	{
		send( msg, "toAntNest");
	}

	else if( tcb.source == ANT_NEST)
	{
		int neighbor = msg->getNeighborChosen();
		int index = findInputGateIDForNeighbor(neighbor);
		queueManagementForMessage(msg, index);
	}

	else
	{
		throw new cException("Unknown source for Ant in Router %d",IPAddress);
	}
}

void Router::processDataPacket(samplePacket *msg)
{

	int hops = msg->getHops();
	
	double life = simTime() - msg->creationTime();

	if( hops >= hopsLimit || life>= lifeLimit)
	{
		sPtr->incrTotalBitsLost();
		delete msg;
	}
	else
	{
		int destination = msg->getDestAddress();

		if(destination == IPAddress)
		{
			send(msg, "toDataSink");

		}
		else
		{
		
			int inputPortIndex = msg->arrivalGateId();

			int nextPortIndex = chooseNextHop(msg);
			// Increase the Number of Hops First
			
			if( nextPortIndex == -1)
			{
				char msg1[100];
				sprintf(msg1,"No OutPort Available for %d in %d", destination, IPAddress);
				perror(msg1);
				exit(-1);
			}

			msg->setHops( msg->getHops() + 1);

			msg->setTimestamp( simTime() );

			queueManagementForMessage(msg,nextPortIndex);
		}
	}
}

int Router::chooseNextHop(samplePacket *msg)
{
	int sourceNode = msg->getSourceAddress();
	int destination = msg->getDestAddress();
	int enterPort = -1;
	int port = -2;

	// Find out from which neighbor this packet arrived
	// and in this case we only need to modify just ack
	// and send flags of the message already in the table

	map<int,pair<int,int>*>::const_iterator J = (*neighborPortID).begin();

	if (sourceNode != IPAddress)
	{
		enterPort = msg->arrivalGateId();
	}

	if(probabilisticRouting)
	{
		if( numNeighbors == 1)
		{	
			return (*J).first;
		}

		else
		{
			// We implemented the routing mechanism as suggested in the paper by combinig
			// the queue length and the probabiltiy. However, the performance somehow thisway
			// is poorer as doing a simple stochastis spread.
/*			double ln= 1.0;
			int qSum = totalQueueLength();
			double probSum = 0.0;
			map<int,double> refineProb;

			for( J = (*neighborPortID).begin(); J != (*neighborPortID).end(); J++)
			{
				port = (*J).first;
				Buffer *sBuff = getBufferForThisPort(port);
				int qn = sBuff->getNormalQueueCapacity() + sBuff->getQuickQueueCapacity();
				int neighbor = (*((*neighborPortID)[port])).second;
				if (qSum != 0)
				{
					ln = 1 - (double) qn/qSum;
				}
				else
				{
					ln = 1;
				}
				double Pnd = getProb(destination, neighbor);
				double PndFinal = Pnd + qWeightFactor * ln;
				probSum += PndFinal;
			}
			

			for( J = (*neighborPortID).begin(); J != (*neighborPortID).end(); J++)
			{
				port = (*J).first;
				Buffer *sBuff = getBufferForThisPort(port);
				int qn = sBuff->getNormalQueueCapacity() + sBuff->getQuickQueueCapacity();
				int neighbor = (*((*neighborPortID)[port])).second;
				if (qSum != 0)
				{
					ln = 1 - (double) qn/qSum;
				}
				else
				{
					ln = 1;
				}
				double Pnd = getProb(destination, neighbor);
				double PndFinal = Pnd + qWeightFactor * ln;
				refineProb[neighbor] = PndFinal/probSum;
			}
*/		
			// Our way of Stochastic Selection
			double incrProb = 0.0;
			double binProb = uniform(0,1);
			int maxPort = -1;
			double bestProb = 0.0;
			for( J = (*neighborPortID).begin(); J != (*neighborPortID).end(); J++)
			{
				port = (*J).first;
				int neighbor = (*((*neighborPortID)[port])).second;

				if( port != enterPort )
				{
					// uncomment the refineProb if want to do the routing in the
					// di carros way.

					double Pnd = getProb(destination, neighbor);
//					double Pnd = refineProb[neighbor];

					if( Pnd >= bestProb)
					{
						bestProb = Pnd;
						maxPort = port;
					}

					incrProb += Pnd;

					if(binProb <= incrProb)
					{
						return port;
					}
				}
			}
			return maxPort;
		}
	}


	// In case we do not want to do probabilistic routing then 
	// we simply route the packet throught highest probabilistic route

	int maxPort = -1;
	double maxPnd = 0;
	
	for( J = (*neighborPortID).begin(); J != (*neighborPortID).end(); J++)
	{
		port = (*J).first;
		int neighbor = (*((*neighborPortID)[port])).second;
		double Pnd = getProb(destination, neighbor);

		if(Pnd >= maxPnd)
		{
			maxPnd = Pnd;
			maxPort = port;
		}
	}
	return maxPort;
}



void Router::processTransmitPacket(cMessage *msg)
{
	int port = msg->kind() - TRANSMIT_PACKET;

	queueManagementForMessage(msg,port);
}

double Router::estimateTimeToNextNode(int neighbor)
{
	int nextInputNode = findInputGateIDForNeighbor(neighbor);

	Buffer *sBuff = getBufferForThisPort(nextInputNode);
	int bitsInBuffer = sBuff->getNormalQueueCapacity() + sBuff->getQuickQueueCapacity();

	// To ensure that in case of zero queue delay the txdelay of the packet will be
	// the queue delay

	int queueLength = bitsInBuffer + (dataPacketLength * BYTE);

	double bandWidth = (*((*bandWidthPdelay)[nextInputNode])).first;
	double pDelay = (*((*bandWidthPdelay)[nextInputNode])).second;
	double qDelay = static_cast<double> ( queueLength/bandWidth );

	return (pDelay + qDelay); 
}

void Router::queueManagementForMessage(cMessage *msg, int port)
{
	Buffer *sBuff = getBufferForThisPort(port);

	if(msg == (*sendControlOrDataPacket)[port])
	{
		if( sBuff->empty() )
		{
			(*msgServiced)[port] = NULL;
		}
		else
		{
			(*msgServiced)[port] = sBuff->fetchNextPacketToSend();
			simtime_t txTime = transmitPacket((*msgServiced)[port], port);
			(*sendControlOrDataPacket)[port]->setKind( TRANSMIT_PACKET + port );
			scheduleAt(simTime() + txTime, (*sendControlOrDataPacket)[port]);

		}
	}
	else if( !(*msgServiced)[port] )
	{
		(*msgServiced)[port] = msg;
		simtime_t txTime = processMessageWhenQueueIsEmpty(msg, port);
		(*sendControlOrDataPacket)[port]->setKind( TRANSMIT_PACKET + port );
		scheduleAt(simTime() + txTime, (*sendControlOrDataPacket)[port]);

	}
	else
	{
		processMessageWhenQueueIsNotEmpty(msg,port);
	}
}

void Router::processMessageWhenQueueIsNotEmpty(cMessage * msg, int port)
{
	int kind = msg->kind();

#ifdef __FLYINGANTS
	if ( kind == NETLAYER_FORWARD_ANT || kind == NETLAYER_BACKWARD_ANT ||
#else
	if ( kind == NETLAYER_BACKWARD_ANT ||
#endif
		kind == NETLAYER_HELLO_PACKET || kind == NETLAYER_HELLO_REPLY_PACKET)
	{
		Buffer *sBuff = getBufferForThisPort(port);
		bool success = sBuff->enqueueInQuickQueue(msg);
#ifdef __FLYINGANTS
		if( (kind == NETLAYER_FORWARD_ANT || kind == NETLAYER_BACKWARD_ANT) && !success)
#else
		if( (kind == NETLAYER_BACKWARD_ANT) && !success)
#endif
		{
			sPtr->incrTotalAntsDeleted();
			delete msg;
		}

		else if ( !success )
		{
			delete msg;
		}
	}
#ifdef __FLYINGANTS
	else if ( kind == NETLAYER_DATA_PACKET)
#else
	else if ( kind == NETLAYER_FORWARD_ANT || kind == NETLAYER_DATA_PACKET)
#endif
	{
		Buffer *sBuff = getBufferForThisPort(port);
		bool success = sBuff->enqueueInNormalQueue(msg);
#ifdef __FLYINGANTS
		if( !success )
		{
			delete msg;
			sPtr->incrTotalBitsLost();
		}
#else
		if( kind == NETLAYER_FORWARD_ANT && !success )
		{
			delete msg;
			sPtr->incrTotalAntsDeleted();
		}
		else if( kind == NETLAYER_DATA_PACKET && !success)
		{
			delete msg;
			sPtr->incrTotalBitsLost();
		}
#endif
	}
	else
	{
		throw new cException("Unknown Message in processMessageWhenQueueIsNotEmpty() %d", kind);

	}
}

double Router::processMessageWhenQueueIsEmpty(cMessage * msg, int port)
{
	double txTime = transmitPacket(msg,port);
	return txTime;
}

double Router::transmitPacket(cMessage * msg, int port)
{
	int kind = msg->kind();
	int length = msg->length();
	int outPort = -1;

	simtime_t txTime = 0.000001;

	//Locat and output gate id from this input gate id

	map<int,pair<int,int>*>::const_iterator P = (*neighborPortID).find(port);
	

	if( P != (*neighborPortID).end())
	{
		pair<int,int>& thePair = *((*P).second);
		outPort = thePair.first;
	}

	else
	{
		throw new cException("Could not locate for %d port an output port", port);
	}


	//1. The Hello Packet has been generated to estimate the bandwidth
	// and Propagation Delay
	if( kind == NETLAYER_HELLO_PACKET)
	{
		helloPacket *hPacket = dynamic_cast<helloPacket*> (msg);
		simtime_t startTime = simTime();
		hPacket->setTxTime( startTime );
	
		send(hPacket, outPort);

		if ( gate(outPort)->toGate()->isBusy())
		{
			simtime_t endTime = gate(outPort)->toGate()->transmissionFinishes();

			txTime = endTime - startTime;

			//Estimate the bandwidth of the channel

			double bandWidth = static_cast<double> ( length / txTime );

			if(debug)
			{
				ev<<"Bandwidth is: " << bandWidth <<endl;
			}

			map<int,pair<double,double>*>::const_iterator I = (*bandWidthPdelay).find(port);

			if( I != (*bandWidthPdelay).end() )
			{
				(*((*bandWidthPdelay)[port])).first = bandWidth;
			}
			else
			{
				pair<double,double> *p = new pair<double,double>(bandWidth,0.0);

				(*bandWidthPdelay)[port] = p;
			}

		}
		else
		{
			send(msg,outPort);
		}

	}
	else
	{
		if( kind == NETLAYER_HELLO_REPLY_PACKET)
		{
			simtime_t inTime = msg->timestamp();
			simtime_t qTime = simTime() - inTime;
			helloPacket *hPacket = dynamic_cast<helloPacket*>(msg);
			hPacket->setQDelayAtNeighbor(qTime);
		}
		else if( kind == NETLAYER_DATA_PACKET)
		{
			simtime_t qTime = simTime() - msg->timestamp();
			sPtr->insertQueueDelay( qTime );
		}
		else if( kind == NETLAYER_FORWARD_ANT || kind == NETLAYER_BACKWARD_ANT)
		{
			Ant *ant = dynamic_cast<Ant*>(msg);
			ant->setSourceModule((int) ROUTER);
			if(simTime() >= converganceTime)
			{
				sPtr->incrTotalAntBits( ant->forwardAntSize() );
			}
		}

		send(msg,outPort);
	}
	double bandWidth = (*((*bandWidthPdelay)[port])).first;
	txTime = static_cast<double> ( length/bandWidth );
	return txTime;
}

Buffer* Router::getBufferForThisPort(int port)
{
	map<int,Buffer*>::const_iterator I = (*qBuffer).find(port);

	if( I != (*qBuffer).end() )
	{
		return (*I).second;
	}
	else
	{
		return NULL;
	}
}

void Router::buildGateIDToNeighborMap()
{
	cGate *outTempGate = gate("out");
	int vectorSize = outTempGate->size();

	for(int i=0; i<vectorSize; i++)
	{
		cGate *outRouterGate = gate("out", i); //access each gate of router
		int gateIDtoNode = outRouterGate->id();
		if(outRouterGate->isConnected())
		{
			
			//get the gate of networkNode to which this gate is connected

			cGate *networkNodeGate = outRouterGate->toGate();
			
			// get the address of the neighbor and then build the map

			if(networkNodeGate->isConnected())
			{
				cModule *neighborNetworkNode = networkNodeGate->toGate()->ownerModule();
				int neighborAddress = neighborNetworkNode->par("address");

				if(debug)
				{
					ev << "Neighbor: " << neighborAddress << "connected to: "<< 
						IPAddress << "at Port: " << gateIDtoNode<<endl;
				}

				int gateIDfromNode = findInputGateIDForNeighbor(neighborAddress);

				pair<int,int> *p = new pair<int,int>(gateIDtoNode,neighborAddress);
				
				(*neighborPortID)[gateIDfromNode] = p; //this is gateID
			}
		}
	}
}

int Router::findInputGateIDForNeighbor(int node)
{
	cGate *inTempGate = gate("in");
	int vectorSize = inTempGate->size();

	for(int i=0; i<vectorSize; i++)
	{
		cGate *inRouterGate = gate("in", i); //access each gate of router
		int gateIDfromNode = inRouterGate->id();
		if(inRouterGate->isConnected())
		{
			
			//get the gate of networkNode to which this gate is connected

			cGate *networkNodeGate = inRouterGate->fromGate();
			
			// get the address of the neighbor and then build the map

			if(networkNodeGate->isConnected())
			{
				cModule *neighborNetworkNode = networkNodeGate->fromGate()->ownerModule();
				int neighborAddress = neighborNetworkNode->par("address");

				if(node == neighborAddress)
				{
					if(debug)
					{
						ev << "Neighbor: " << neighborAddress << "connected to: "<< 
							IPAddress << "at Port: " << gateIDfromNode <<endl;
					}
					return gateIDfromNode;
				}

			}
		}
	}
	throw new cException("Could not locate gate to router %d from %d in findInputGateForNeighbor",
	node, IPAddress);
}


void Router::clearAllBuffersOfRouter()
{
	map<int,Buffer*>::const_iterator I;

	for( I = (*qBuffer).begin(); I != (*qBuffer).end(); I++)
	{
		Buffer *sBuff = (*I).second;
		int bCount = 0, dCount = 0;
		sBuff->clear(bCount,dCount);
		sPtr->incrPacketInQueue( dCount );
		(*msgServiced)[(*I).first] = NULL;
	}
}

void Router::findSourceForAnt(Ant *msg)
{
	int source = msg->getSourceModule();

	if( source == ANT_NEST)
	{
		tcb.source = ANT_NEST;
	}

	else if (source == ROUTER)
	{
		tcb.source = ROUTER;
	}
}

int Router::getNumNeighbors() 
{ 
	return numNeighbors; 
}

double Router::getProb(int destination, int neighbor) 
{ 
	int port = findInputGateIDForNeighbor(neighbor);
	return rTable->getDestViaThisNeighborProb(destination, port);
}

void Router::setProb(int destination, int neighbor, double prob) 
{
	int port = findInputGateIDForNeighbor(neighbor);
	rTable->setDestViaThisNeighborProb(destination, port, prob);
}

int Router::getNumNodes()
{
	return numNodes;
}

int Router::getMyAddress()
{
	return IPAddress;
}

// This function has now become redundant as the queueLength function
// does the same thing, however, we are keeping it to make sure that
// it remains backward compatible with the function in AntNest:)

double Router::bitsInQueue(int neighbor)
{
	int nextInputNode = findInputGateIDForNeighbor(neighbor);
	Buffer *sBuff = getBufferForThisPort(nextInputNode);
	int bitsInBuffer = sBuff->getNormalQueueCapacity() + sBuff->getQuickQueueCapacity();
	return bitsInBuffer;
}

int Router::queueLength(int neighbor)
{
	int nextInputNode = findInputGateIDForNeighbor(neighbor);

	Buffer *sBuff = getBufferForThisPort(nextInputNode);
	int bitsInBuffer = sBuff->getNormalQueueCapacity() + sBuff->getQuickQueueCapacity();
	return bitsInBuffer;

}

int Router::totalQueueLength()
{
	int totalQ = 0;

	map<int,Buffer*>::const_iterator I;
	for( I = (*qBuffer).begin(); I != (*qBuffer).end(); I++)
	{
		Buffer *sBuff = (*I).second;
		totalQ += sBuff->getNormalQueueCapacity() + sBuff->getQuickQueueCapacity();
	}
	return totalQ;
}


int Router::getQueueMaxLen()
{
	return queueSize;
}

double Router::getBandwidth(int neighbor)
{
	int enterPort = findInputGateIDForNeighbor(neighbor);
	double bandWidth = (*((*bandWidthPdelay)[enterPort])).first;
	return bandWidth;
}

void Router::initAntRoutingTable(double initial)
{
	map<int,pair<int,int>*>::const_iterator I;

	for(int i = 0; i < numNodes; i++)
	{
		if( i != IPAddress)
		{
			for(I = (*neighborPortID).begin(); I != (*neighborPortID).end() ; I++)
			{
				int port = (*I).first;
				rTable->setDestViaThisNeighborProb(i, port, initial);
			}
		}
	}
}

int Router::findNeighborAtIndex(int index)
{
	if( index < numNeighbors)
	{
		return neighborAtIndex[index];
	}
	else
	{
		throw new cException("Index %d in Router %d is out of bound", index, IPAddress);
	}
}

int Router::findIndexForNeighbor(int neighbor)
{
	for(int i = 0; i < numNeighbors ; i++)
	{
		if( neighborAtIndex[i] == neighbor)
		{
			return i;			
		}
	}
	throw new cException("Router %d Index not found for Neighbor %d ", IPAddress, neighbor);
}


void Router::finish()
{
	ev << "Module: " << fullPath() << endl;

	map<int,Buffer*>::const_iterator I;

	for( I = (*qBuffer).begin(); I != (*qBuffer).end(); I++)
	{
		Buffer *sBuff = (*I).second;
		int bCount = 0, dCount = 0;
		sBuff->clear(bCount,dCount);
		sPtr->incrPacketInQueue( dCount );
	}

	sPtr->incrEntriesInRoutingTable( numNodes * numNeighbors);

	map<int,pair<int,int>*>::const_iterator J;

	for( J = (*neighborPortID).begin(); J != (*neighborPortID).end(); J++)
	{
		int port = (*J).first;
		double bandWidth = (*((*bandWidthPdelay)[port])).first;
		sPtr->incrTotalBandWidthInNetwork( bandWidth );
	}
}

