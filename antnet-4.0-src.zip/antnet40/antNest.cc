// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System,
// Universitaet Dortmund
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: antNest.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include "antNest.h"

/* #define original */

// There are small variations suggested by the author of AnNet Algorithm.
// If some one wants to omitt them then simply uncomment following line

/* #define original */

Define_Module( antNest );

antNest::antNest(const char *name, cModule *parentmodule, unsigned stacksize)
  : cSimpleModule(name, parentmodule,stacksize)
{
	averageOfTimeToDest = NULL;
	varianceOfTimeToDest = NULL;
	bestTimeToDest = NULL;
	timeWindowSamples = NULL;
	bestTimeToDestInWindow = NULL;
}

antNest::~antNest()
{
	delete[] averageOfTimeToDest;
	delete[] varianceOfTimeToDest;
	delete[] bestTimeToDest;
	delete[] timeWindowSamples;
	delete[] bestTimeToDestInWindow;
}

void antNest::initializeNestFromRouter()
{
	antsDeleted = 0;

	ptr = (Router *) gate("toRouter")->toGate()->ownerModule();

	numNeighbors = ptr->getNumNeighbors();
	numNodes = ptr->getNumNodes();

	queueSize = ptr->getQueueMaxLen();
	myAddress = ptr->getMyAddress();

	const char *statModulePath = par("statModulePath");
	cModule *tmp1 = simulation.moduleByPath(statModulePath);
	sPtr= check_and_cast<statistics *> (tmp1);


	hopsLimit = (int) (maxHopsCoefficient * numNodes);

	// Co-efficient of exponential (n) means is used to compute
	// exponential averages for the local traffic statistics
	// 5*(1/n). Hence with the help of this
	// coefficient we could easily determine the number
	// of samples that must be used in the computation
	// of interval of confidence.

	exponentialWinSize = (int) (1./expMeanCoefficient) * 5;

	squreExpWinSize = (int) sqrt( (double)exponentialWinSize );

	//  The purpose of this window size is to determine the
	//  best round trip time over a window and then use it
	//  in the reinforcement. Reinforcement takes into account
	//  the ratio between current trip time and the best
	//  trip time observed over this window.
	//  | Wmax | = 5*(c/n) where c is windowSizeCoefficient

	windowSize = (int) (windowSizeCoefficient * exponentialWinSize);

	// initializing the probability in a uniform fashion


	const double initialTransProb = 1./numNeighbors;
	ptr->initAntRoutingTable(initialTransProb);

	averageOfTimeToDest = new double[numNodes];
	varianceOfTimeToDest = new double[numNodes];
	bestTimeToDest = new double[numNodes];
	timeWindowSamples = new int[numNodes];
	bestTimeToDestInWindow = new double[numNodes];

	for(int k = 0; k < numNodes; k++)
	{
		timeWindowSamples[k] = 0;
		bestTimeToDest[k] = MAXFLOAT;
		bestTimeToDestInWindow[k] = MAXFLOAT;
		averageOfTimeToDest[k] = 0.0;
		varianceOfTimeToDest[k] = 0.0;
	}
}

void antNest::initialize()
{
	expMeanCoefficient = par("expMeanCoefficient");
	windowSizeCoefficient = par("windowSizeCoefficient");
	zetaConfidenceLevel = par("zetaConfidenceLevel");
	explorationProbablity = par("explorationProbablity");
	rescalingPower = par("rescalingPower");
	queueWeight = par("queueWeight");
	forkProbability = par("forkProbability");
	maxHopsCoefficient = par("maxHopsCoefficient");
	ageLimit = par("ageLimit");
	squashFunctionCoefficient = par("squashFunctionCoefficient");
	probabilisticRouting = par("probabilisticRouting");
	timeWeight = par("timeWeight");
	converganceTime = par("converganceTime");

	double sleepTime = (double) par("sleepTimeAtStart");
	initRouter = new cMessage("InitRouter");
	scheduleAt( simTime() + sleepTime, initRouter);
}

void antNest::handleMessage(cMessage *msg)
{
	int kind = msg->kind();

	if(kind == NETLAYER_FORWARD_ANT)
	{
		current = (Ant *) msg;
		int size = current->forwardAntSize();
		current->setLength( size );
		processForwardAnts();
	}
	else if(kind == NETLAYER_BACKWARD_ANT)
	{
		current = (Ant *) msg;
		int size = current->backwardAntSize( current->length() );
		current->setLength( size );
		processBackwardAnts();
	}
	else if( msg == initRouter)
	{
		initializeNestFromRouter();
	}
	else
	{
		throw new cException("Unknown Message %d in AntNest of router %d",
								kind, myAddress);
	}
}

void antNest::processForwardAnts()
{
	bool antDeleted = false;
	// 1. Check whether hop or age limit has been reached

	// 2. check whether the ant has reached the destination

	if( current->getDestNode() == myAddress)
	{
		current->setKind( NETLAYER_BACKWARD_ANT );

		// Determine the previous node and set it as neighbor chosen
		// to simpliy processing of this ant at router module

		int previousNode = (current->topOfStack()).nodeAddress;

		current->setNeighborChosen(previousNode);

		antStackEntry entry;
		entry.nodeAddress = myAddress;
		entry.nodeEntranceTime = simTime();
		entry.estimatedEntryTime = current->getTimeAtNextHop(); //this was the time estimated at the last node

		// now do the recording keep values by pushing the
		// entrance time and nodeID onto the stack.
		// for quick checking of cycles, we keep another
		// array for the nodes being visited by the ant.

		current->addToVisitedNodes( myAddress );
		current->addToCycleNodes( entry );


	}

	else
	{
		// Determine if ant were generated at this node
		findSourceForAnt( current );

		if(nTcb.source == ROUTER)
		{
			//3. doForwardAntActions()

			antDeleted = doForwardAntActions();

		}

		else if (nTcb.source == ANT_GEN)
		{
			selectLinks();
		}
	}

	// Finally now send this forward ant back to the router

	if( !antDeleted )
	{
		int hops = current->getHops();
		hops++;
		current->setHops(hops);

		current->setSourceModule( (int) ANT_NEST);
		send(current,"toRouter");
	}
}

void antNest::processBackwardAnts()
{

	// Update Routing Table
	doBackwardAntActions();
	int hops = current->getHops();
	hops++;
	current->setHops(hops);

	if(current->getSourceNode() == myAddress)
	{
		// send to the sink
		send(current,"toAntSink");

	}

	else
	{
		// set the source of this ant
		current->setSourceModule( (int) ANT_NEST);
		send(current,"toRouter");
	}
}

void antNest::doBackwardAntActions()
{

	int dest = current->getDestNode();
	updateRoutingTable(dest);
}

void antNest::selectLinks()
{
		int destNode = current->getDestNode();
		int nextHop = 0;

		int fLinks = 0; // number of feasible links
		nodeProbPair *goodnessProbability = new nodeProbPair[numNeighbors];

		// calculate goodness for feasible links

		goodnessForFeasibleLinks(destNode,fLinks,goodnessProbability);

		int node = 0;
#ifdef original
		if( explorationProbablity > 0 &&
			(node = selectLinkInRandomUniformWay()) != UNIFORM_RANDOM_SELECTION_FAILED)
#else
// GIANNI
		double prob = uniform(0.0, 1.0);
		if( explorationProbablity > prob &&
			(node = selectLinkInRandomUniformWay()) != UNIFORM_RANDOM_SELECTION_FAILED)
#endif
		{

			nextHop = node;
		}

	  // Select the outlink in a probabilistic proportional way according to the
	  // computed goodness estimates goodnessProbability. The selection is made among
	  // the nodes not visited yet. If all the nodes have been already visited,
	  // the one with the highest goodness estimate is deterministically selected

#ifdef original
		else if (fLinks == numNeighbors) // all neighbors visited
		{
			nextHop = selectLinkWithHighestGoodness(fLinks, goodnessProbability);
		}
#else
// GIANNI
		else if (fLinks == numNeighbors) // all neighbors visited
		{
		  node = selectLinkInRandomUniformWay();
		  if( node == UNIFORM_RANDOM_SELECTION_FAILED )
		    node =  ptr->findNeighborAtIndex(0);
		  nextHop = node;
		}
#endif
		else
		{
#ifdef original
		  double binProb = uniform(0.0,1.0);


		  if( binProb <= 0.75)
		    {
		      nextHop = selectLinkInRandomPropotionalWay(fLinks, goodnessProbability);

		    }
		  else
		    {
		      nextHop = selectLinkWithHighestGoodness(fLinks, goodnessProbability);
		    }
#else
//GIANNI
		  double binProb = uniform(0.0,1.0);

		  nextHop = selectLinkInRandomPropotionalWay(fLinks, goodnessProbability);
#endif

		}

		delete[] goodnessProbability;


		antStackEntry entry;
		entry.nodeAddress = myAddress;
		entry.nodeEntranceTime = simTime();
		entry.estimatedEntryTime = current->getTimeAtNextHop(); //this was the time estimated at the last node

		// now do the recording keep values by pushing the
		// entrance time and nodeID onto the stack.
		// for quick checking of cycles, we keep another
		// array for the nodes being visited by the ant.

		current->setNeighborChosen( nextHop );
		current->addToVisitedNodes( myAddress );
		current->addToCycleNodes( entry );

}

bool antNest::doForwardAntActions()
{
	// check if this ant reached age or hop limits

	if( !checkIfAntReachedAgeOrHopsLimitThenDelete())
	{
		if( !checkIfAntIsObsoleteThenDelete() )
		{
			selectLinks();
			return false;
		}
	}

	antsDeleted++;
	sPtr->incrTotalAntsDeleted();
	return true;

	// do nothing as this ant has been deleted
}

#ifdef original
int antNest::selectLinkInRandomUniformWay()
{
	double prob = uniform(0.0, 1.0);
	int index = 0;

	int sourceNode = current->getSourceNode();

	if ( sourceNode != myAddress)
	{
		int lastNode = (current->topOfStack()).nodeAddress;

		int neighborIndex = ptr->findIndexForNeighbor(lastNode);

		if( prob < explorationProbablity)
		{
			// Do not select the same neighbor from which this ant came
			while(( index = intrand( numNeighbors )) == neighborIndex)
			{

				int neighbor = ptr->findNeighborAtIndex(index);
				return neighbor;
			}
		}
	}

	else
	{
		if( prob < explorationProbablity)
		{
			int index = intrand( numNeighbors );
			int neighbor = ptr->findNeighborAtIndex(index);
			return neighbor;
		}

	}


	return UNIFORM_RANDOM_SELECTION_FAILED;
}
#else
// GIANNI

int antNest::selectLinkInRandomUniformWay()
{
  int index = 0;

  int sourceNode = current->getSourceNode();

  if( numNeighbors == 1 )
    return UNIFORM_RANDOM_SELECTION_FAILED;

  if ( sourceNode != myAddress)
    {
      int lastNode = (current->topOfStack()).nodeAddress;

      int lastNodeNeighborIndex = ptr->findIndexForNeighbor(lastNode);

      // Do not select the same neighbor from which this ant came
      while(1)
	{
	  index = intrand( numNeighbors );

	  if(index != lastNodeNeighborIndex)
	    return ptr->findNeighborAtIndex(index);
	}
    }
  else
    {
      int index = intrand( numNeighbors );
      return ptr->findNeighborAtIndex(index);
    }

  return UNIFORM_RANDOM_SELECTION_FAILED;
}
#endif


int antNest::selectLinkInRandomUniformWayAntsGeneratedAtThisNode()
{


	int neighbor;
	do
	{
		// Do not select the node that generated current ant as next hop
		int index =  intrand( numNeighbors);
		neighbor = ptr->findNeighborAtIndex(index);


	} while ( neighbor == myAddress);

	return neighbor;


}

int antNest::selectLinkInRandomPropotionalWay(int count, nodeProbPair *goodnessProb)
{
	double incrProb = 0.0;
	int selectedNeighbor = -2;
	int neighbor;
	double binProb = uniform(0.0, 1.0);
	int lastNode;

	int sourceNode = current->getSourceNode();

	// if ant is origanted at this node, so it would not be having
	// any last node hence we could set it to currentNode. In this
	// way neighbor != lastNode will be true in any case


	if( sourceNode != myAddress)
	{
		lastNode = (current->topOfStack()).nodeAddress;
	}
	else
	{
		lastNode = myAddress;
	}

	// we need to ensure that we do not send the ant to the same node
	// from where it arrived.
	for(int i = 0; i < numNeighbors; i++)
	{
		int k = goodnessProb[i].neighbor;

		if ( k != -1)
		{
			incrProb += goodnessProb[i].value;
			neighbor = goodnessProb[i].neighbor;

			if( binProb <= incrProb && neighbor != lastNode)
			{
				return neighbor;
			}
		}
	}

	for(int j = 0; j < numNeighbors; j++)
	{
		int k = goodnessProb[j].neighbor;

		if ( k != -1 && k != lastNode)
		{
			selectedNeighbor = k;
			break;
		}
	}

	if(selectedNeighbor == -2)
	{
		selectedNeighbor = lastNode;
	}
	return selectedNeighbor;
}

int antNest::selectLinkWithHighestGoodness(int count, nodeProbPair *goodnessProb)
{
	nodeProbPair temp;
	temp.value = 0.0;
	temp.neighbor = -2;

	int lastNode;

	int sourceNode = current->getSourceNode();

	// if ant is origanted at this node, so it would not be having
	// any last node hence we could set it to currentNode. In this
	// way neighbor != lastNode will be true in any case


	if( sourceNode != myAddress)
	{
		 lastNode = (current->topOfStack()).nodeAddress;
	}
	else
	{
		lastNode = myAddress;
	}

	for(int i = 0; i < numNeighbors; i++)
	{
		int k = goodnessProb[i].neighbor;

		if ( k != -1 && k != lastNode)
		{
			if ( goodnessProb[i].value > temp.value )
			{
				temp.value = goodnessProb[i].value;
				temp.neighbor = goodnessProb[i].neighbor;

			}
		}
	}

	if(temp.neighbor == -2)
	{
		temp.neighbor = lastNode;
	}
	return temp.neighbor;
}


void antNest::goodnessForFeasibleLinks(int destNode, int& count, nodeProbPair *goodnessProb)
{

	int feasibleNeighbors = 0;
	double normGoodness = 0.0;
	nodeProbPair *neighbors = new nodeProbPair[numNeighbors];

	heuristicCorrectionFactor(feasibleNeighbors, neighbors);


	count = feasibleNeighbors;


	for(int i = 0; i < numNeighbors ; i++)
	{
		int k =  neighbors[i].neighbor;

		if ( k != -1)
		{
			int neighbor = neighbors[i].neighbor;
			double Pnd = ptr->getProb(destNode,neighbor);

			// Pnd + aplha * Ln

			double ln = neighbors[i].value;

			double Pgoodness = Pnd + queueWeight * ln;
			normGoodness += Pgoodness;
		}
	}

	for(int j = 0; j < numNeighbors ; j++)
	{
		int k = neighbors[j].neighbor;

		if ( k != -1)
		{
			int neighbor = neighbors[j].neighbor;

			double Pnd = ptr->getProb(destNode,neighbor);

			// Pnd + aplha * Ln

			double ln = neighbors[j].value;

			double Pgoodness = Pnd + queueWeight * ln;

			goodnessProb[j].neighbor = neighbor;
			goodnessProb[j].value = Pgoodness / normGoodness;
		}
		else
		{
			goodnessProb[j].neighbor = k;
		}
	}
	delete[] neighbors;

}

// ln = 1 - qn/sum(qn�) and qn� is set of all feasible neighbors

void antNest::heuristicCorrectionFactor(int& count,nodeProbPair *hFactor)
{
	double sumDelay = totalDelayOfFeasiblelinks();
	int fLinks = 0;

	for(int i = 0; i < numNeighbors; i++)
	{
		int neighbor = ptr->findNeighborAtIndex(i);
		hFactor[i].neighbor = -1;

		if( !nodeAlreadyVisited(neighbor) || allNeighborsVisited())
		{
			double numBits = ptr->bitsInQueue(neighbor);
			double dataRate = ptr->getBandwidth(neighbor);
			double linkDelay = numBits / dataRate;

			double normalizedLinkDelay = linkDelay / sumDelay;

			hFactor[i].neighbor = neighbor;
			hFactor[i].value = 1 - normalizedLinkDelay;
			fLinks++;
		}
	}
	count = fLinks;
}

double antNest::totalDelayOfFeasiblelinks()
{
	double delaySum = 0.0;

	for(int i = 0; i < numNeighbors; i++)
	{
		int neighbor = ptr->findNeighborAtIndex(i);

		if( !nodeAlreadyVisited(neighbor) || allNeighborsVisited())
		{
			double numBits = ptr->bitsInQueue(neighbor);
			double dataRate = ptr->getBandwidth(neighbor);
			double linkDelay = numBits / dataRate;

			delaySum += linkDelay;
		}
	}
	return delaySum;
}

double antNest::getReinforcement(double tripTime, int destNode)
{
	/* Average of Time Window */

	double average = averageOfTimeToDest[destNode];

	/* Variance of time window */

	double variance = varianceOfTimeToDest[destNode];

	/* Best Time in window */

	double Wbest = bestTimeToDestInWindow[destNode];

	double z = zetaConfidenceLevel;
	double c2 = timeWeight;
	double c1 = 1 - c2;
	double Isup = 0.0;
	double T = tripTime;


	/* conidence inrerval limit for value of average of time in window */

	if( average > Wbest)
	{
		Isup = average + z * ( variance / sqrt((double)windowSize) );
	}

	else
	{
		Isup = Wbest + z * ( variance / sqrt((double)windowSize) );
	}


	/* confidence interval limit for the average value of the window */

	double Iinf = Wbest;
	double reinforcement = 0.0;

	double currentTimeToBestRatio = ((Wbest / T));
	double  stabilityOfCurrentValue =  ((Isup - Iinf) / ((Isup - Iinf) + (T - Iinf)));


	if(currentTimeToBestRatio >= 0.99 && stabilityOfCurrentValue >=0.99)
	{
		reinforcement = 0.95;
	}
	else
	{
		reinforcement = c1 * currentTimeToBestRatio + c2 * stabilityOfCurrentValue;
	}

	double r = squashedReinforcement(reinforcement);


	if( r <= 0.0 || r >= 1.0)
	{
		throw new cException("Reinformcemt Value in %d for %d is %f and invalid",
			myAddress, destNode,r);
	}
	return r;
}


void antNest::updateLocalTrafficModel(double Tdest, int destNode)
{
	/* Average of Time Window */

	double average = averageOfTimeToDest[destNode];

	/* Variance of time window */

	double variance = varianceOfTimeToDest[destNode];

	/* Best Time in window */

	double Wbest = bestTimeToDestInWindow[destNode];

	/* current sample number */

	int count = timeWindowSamples[destNode];

	double z = zetaConfidenceLevel;


	/* The factor n weights the number of most recenet samples that
	   will effece the average */

	double n = expMeanCoefficient;

	double Isup = average + z * ( variance / squreExpWinSize );


	// We update the local traffic model only if the
	// trip time is within confidence interval Isup
	// that means for some sort of legal values

//	if( Tdest < Isup || (average == 0 && variance == 0))
//	{

		/* Ud <- Ud + n(Ok->d - Ud) */

		double diff = Tdest - average;
		average = average + n * diff;
		averageOfTimeToDest[destNode] = average;

		/* Od^2 <- Od^2 + n( (Ok->d - Ud)^2 - Od^2) */

//		variance = variance + n *( pow((fabs(diff)),2) - variance);
		variance = variance + n * ( fabs(diff) - variance);
		varianceOfTimeToDest[destNode] = variance;

		/* If first sample of the window or in case of better value */

		if ( count == 0 || Tdest < Wbest)
		{
			bestTimeToDestInWindow[destNode] = Tdest;
		}

		count = (count + 1) % windowSize;
		timeWindowSamples[destNode] = count;
//	}
}

void antNest::updateProbabilityModel(int neighbor, int destNode, double r, bool increment)
{
	double Pnd = ptr->getProb(destNode,neighbor);

	if( increment )
	{
		Pnd = Pnd + r * ( 1 - Pnd );
	}

	else
	{
		Pnd = Pnd - r * Pnd;
	}

	ptr->setProb(destNode,neighbor,Pnd);
}

void antNest::updateRoutingTableAndTrafficeModelEntries(int destNode, int lastNeighbor, double timeToDest)
{
	updateLocalTrafficModel(timeToDest, destNode);

	simtime_t currentTime = simTime();

	if( currentTime >= converganceTime)
	{


		double r = getReinforcement( timeToDest, destNode);

		for(int i = 0; i < numNeighbors; i++)
		{
			int neighbor = ptr->findNeighborAtIndex(i);

			if( neighbor == lastNeighbor)
			{
				updateProbabilityModel(neighbor, destNode, r, true);
			}

			else
			{
				updateProbabilityModel(neighbor, destNode, r, false);
			}
		}

		// rescale values

		rescaleProbabilitiesForDataPackets(destNode);
	}

}


void antNest::updateRoutingTable(int destNode)
{
	// To calculate the trip time from current node to the  sub destination
	// we apply the following algorithm
	// 1. Stack is implemented using a vector for simplification of
	//    subpath updation
	// 2. Since we use push_back, hence first node visited is at
	//    begin() and last node visited is towards the end of the
	//    vector
	// 3. We determine the position of current node in vector
	// 4. From current node to destination node(last entry) we
	//    create a new vector for our processing
	// 5. First entry of this node is current node, hence we save it.
	// 6. We keep on iterating on the nodes and destinaton node is
	//    always updated while in case of subpaths only good subpaths
	//    are updated.
	// 7. Time to different nodes is difference of entrance times
	//    both nodes


	vector<antStackEntry*>::iterator iter;
	vector<antStackEntry*>::iterator tempIter;
	vector<antStackEntry*>::iterator endIter;

	tempIter = current->currentNodeIter(myAddress);

	endIter = current->destNodeIter();




	// Since we have used pushed back function, hence all nodes visited from
	// current node to destination node will be from current position till end

	vector<antStackEntry*> subPathNodes;
	subPathNodes.assign(tempIter,endIter);

	iter = subPathNodes.begin();

	antStackEntry currentNodeEntry = *(*iter);

	++iter; // go to neighbor; Neighbor Entry from where ant came
	antStackEntry neighborEntry = *(*iter);

	if( current->getSourceNode() != myAddress)
	{
		--tempIter; // find out next hop

		int nextHop = (*(*tempIter)).nodeAddress;
		current->setNeighborChosen( nextHop );
	}


	if( currentNodeEntry.nodeAddress == myAddress)
	{

	// now iterate over it by first incrementing so that we are at the
	// second neighbor

		for(iter; iter!= subPathNodes.end(); ++iter)
		{
			antStackEntry temp = *(*iter);


			int subPathDestNode = temp.nodeAddress;

			/* Average of Time Window */

			double average = averageOfTimeToDest[subPathDestNode];

			/* Variance of time window */

			double variance = varianceOfTimeToDest[subPathDestNode];

			double z = zetaConfidenceLevel;

			// This is a measure of goodness of subpaths, we call
			// a subpath good if its trip time is less than Isup

			double Isup = average + z * ( variance / squreExpWinSize );

#ifdef __FLYINGANTS
			double timeToThisNode =
				temp.estimatedEntryTime - currentNodeEntry.estimatedEntryTime;
#else
			double timeToThisNode =
				temp.nodeEntranceTime - currentNodeEntry.nodeEntranceTime;
#endif
			// always update routing table for destination node
			// update another entries only if they form a good subpath

			if( timeToThisNode < Isup || temp.nodeAddress == current->getDestNode())
			{
				updateRoutingTableAndTrafficeModelEntries(subPathDestNode,neighborEntry.nodeAddress,timeToThisNode);

			}
		}
	}

	else
	{
		throw new cException(" Ant should have come to %d while it is to %d",
								myAddress, currentNodeEntry.nodeAddress);
	}
}


void antNest::findSourceForAnt(Ant *msg)
{

	int source = msg->getSourceModule();

	if( source == ANT_GEN)
	{
		nTcb.source = ANT_GEN;
	}

	else if (source == ROUTER)
	{
		nTcb.source = ROUTER;
	}
}


// This method enhances good probabilites and penalizes small
// probabilites  f(p) = (p)^alpha

void antNest::rescaleProbabilitiesForDataPackets(int destNode)
{


	// get number of neighbors

	double probSum = 0.0;


	for(int i = 0; i < numNeighbors; i++)
	{
		int neighbor = ptr->findNeighborAtIndex(i);
		double probValue = ptr->getProb(destNode,neighbor);

		if( probValue > 1.0e-6)
		{
			probValue = pow(probValue, rescalingPower);
			probSum += probValue;
			ptr->setProb(destNode,neighbor,probValue);
		}

		else
		{
			probValue = 0.0;
			ptr->setProb(destNode,neighbor,probValue);
		}
	}

	// Normalizing Probabilites

	for(int j = 0;  j < numNeighbors; j++)
	{
		int neighbor = ptr->findNeighborAtIndex(j);
		double probValue = ptr->getProb(destNode,neighbor);
		probValue /= probSum;
		ptr->setProb(destNode,neighbor,probValue);
	}

}


//
// s(x) = (1 + exp( a/ (x*Nk))^-1

double  antNest::squashingFunction(int neighbors, double reinf)
{
  //GIANNI
  /*
	double saturationCoeff = squashFunctionCoefficient  /(double)neighbors;
	double normalizedCoefficient =
		((1. / (1. + exp(- saturationCoeff * reinf ))) - 0.5);
  */
	double saturationCoeff = squashFunctionCoefficient  /(double)neighbors;
	double normalizedCoefficient = 1. / (1. + exp(saturationCoeff / reinf));
	return normalizedCoefficient;
}

//  r <- s(r) / s(1)

double antNest::squashedReinforcement(double reinf)
{
	double rEnf = squashingFunction(numNeighbors, reinf);
	double nEnf = squashingFunction(numNeighbors, 1.0);

	return ( rEnf / nEnf);
}


bool antNest::allNeighborsVisited()
{
	bool continueTest = true;

	int i = 0;

	while (i < numNeighbors && continueTest == true)
	{
		int neighbor = ptr->findNeighborAtIndex(i);

		if( !nodeAlreadyVisited(neighbor))
		{
			continueTest = false;
		}
		i++;
	};

	return continueTest;
}

bool antNest::nodeAlreadyVisited(int node)
{
	int nodes = current->getVisitedNodesArraySize();

	for(int i = 0; i < nodes; i++)
	{
		int temp = current->getVisitedNodes(i);
		if( temp == node )
		{
			return true;
		}
	}

	return false;
}

bool antNest::nodeCycleAlreadyVisited(int node)
{
	int nodes = current->getCycleNodesArraySize();

	for(int i = 0; i < nodes; i++)
	{
		antStackEntry temp = current->getCycleNodes(i);
		if( temp.nodeAddress == node )
		{
			return true;
		}
	}

	return false;
}

bool antNest::doCycleExist(int node)
{
	if( nodeCycleAlreadyVisited(node) )
	{
		return true;
	}

	return false;
}

bool antNest::checkIfAntReachedAgeOrHopsLimitThenDelete()
{

 	double currentTime = simTime();

	double life =  currentTime - current->creationTime();
	int hops =  current->getHops();
	if( life >= ageLimit || hops >= hopsLimit)
	{
		sPtr->insertAntLife( simTime() - current->creationTime() );
		sPtr->incrAntHops( current->getHops() );
		delete current;
		return true;
	}
	return false;
}



bool antNest::checkIfAntIsObsoleteThenDelete()
{
	int currentNode = myAddress;

	if (doCycleExist(currentNode)) // Loop has been detected
	{

		double currentTime = simTime();
		// now deleting all entries in the cycle


		antStackEntry temp = current->topOfStack();
		current->deleteCycleNode(temp.nodeAddress);

		while( temp.nodeAddress != currentNode)
		{
			temp = current->topOfStack();
			current->deleteCycleNode(temp.nodeAddress);
		};

		double timeInCycle = currentTime - temp.nodeEntranceTime;

		double timeBeforeEntryIntoCycle = temp.nodeEntranceTime - current->creationTime();

		double totalLife = currentTime - current->creationTime();

		// delete this ant as it might be carrying an old and misleading
		// information about the network state and it is counterproductive
		// to use it for updating the routing tables
		// In this case ant might have waisted a lot of time probably
		// because of wrong sequence of decisons and not because of
		// congestion states.


		if( timeInCycle >= timeBeforeEntryIntoCycle)
		{
			// simple delete this ant

			sPtr->insertAntLife( simTime() - current->creationTime() );
			sPtr->incrAntHops( current->getHops() );
			delete current;
			return true;
		}
	}

	return false;
}

void antNest::finish()
{
    ev << "*** Module: " << fullPath() << "***" << endl;

	ev << "Ants Deleted:   " << antsDeleted << endl;
}

