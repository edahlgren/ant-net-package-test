// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: ant.cpp
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------

#include "ant.h"

Register_Class( Ant );

Ant::Ant(const char *name): Ant_Base(name)
{
	this->sourceNode_var = 0;
	this->destNode_var = 0;
}

Ant::Ant(int source, int destination, const char*name): Ant_Base(name)
{
	this->sourceNode_var = source;
	this->destNode_var = destination;
}

Ant::~Ant()
{
	vector<antStackEntry*>::iterator iter;


	for(iter = cycleNodes.begin(); iter != cycleNodes.end(); ++iter)
	{
		antStackEntry *temp = *iter;
		delete temp;
	} //endfor
}

Ant::Ant(const Ant& other): Ant_Base(other.name())
{
	operator=(other);
}

Ant& Ant::operator=(const Ant& other)
{
	if(this == &other)
	{
		return *this;
	}
	else
	{
		this->neighborChosen = other.neighborChosen;
		this->sourceModule = other.sourceModule;
		Ant_Base::operator =(other);
		visitedNodes.assign(other.visitedNodes.begin(), other.visitedNodes.end());
		cycleNodes.assign(other.cycleNodes.begin(), other.cycleNodes.end());
		return *this;		
	}
}

cObject* Ant::dup() const
{
	return new Ant(*this);
}

void Ant::setVisitedNodesArraySize(unsigned int size){}

unsigned unsigned int Ant::getVisitedNodesArraySize() const
{
	return visitedNodes.size();
}

int Ant::getVisitedNodes(unsigned int k) const
{
	return visitedNodes[k];
	
}

void Ant::setVisitedNodes(unsigned int k, int node)
{
	visitedNodes[k] = node;
}


void Ant::addToVisitedNodes(const int& node)
{
	visitedNodes.push_back(node);
}

bool Ant::nodeAlreadyVisited(const int& node)
{
	vector<int>::iterator iter;

	for(iter = visitedNodes.begin(); iter != visitedNodes.end(); ++iter)
	{
		int temp = *iter;
		if( temp == node)
		{
			return true;
		}
	} //endfor

	return false;
}

void Ant::setNeighborChosen(int neighbor)
{
	neighborChosen = neighbor;
}

int Ant::getNeighborChosen()
{
	return neighborChosen;
}

void Ant::setSourceModule(int module)
{
	sourceModule = (int) module;
}

int Ant::getSourceModule()
{
	return sourceModule;
}

void Ant::showVisitedNodeVector()
{
	vector<int>::iterator iter;

	for(iter = visitedNodes.begin(); iter != visitedNodes.end(); ++iter)
	{
		int temp = *iter;
		ev<< "Node Visited is: " << temp << endl;
	} //endfor
}

void Ant::setCycleNodesArraySize(unsigned int size)
{

}

unsigned int Ant::getCycleNodesArraySize() const
{
	return cycleNodes.size();
}

antStackEntry& Ant::getCycleNodes(unsigned int k) 
{
	antStackEntry *temp = cycleNodes[k];
	return *temp;
}

void Ant::setCycleNodes(unsigned int k, const antStackEntry& entry)
{
	antStackEntry *ptr = new antStackEntry(entry);
	cycleNodes[k] = ptr;
}

void Ant::addToCycleNodes(const antStackEntry& entry)
{
	antStackEntry *ptr = new antStackEntry(entry);
	cycleNodes.push_back(ptr);
}

bool Ant::cycleNodeAlreadyVisited(const int& node)
{
	vector<antStackEntry*>::iterator iter;

	for(iter = cycleNodes.begin(); iter != cycleNodes.end(); ++iter)
	{
		antStackEntry *temp = *iter;
		if( (*temp).nodeAddress == node)
		{
			return true;
		}
	} //endfor

	return false;
}

int Ant::getPreviousNode(int node)
{
	vector<antStackEntry*>::iterator iter;
	iter = currentNodeIter(node);
	--iter;

	antStackEntry *temp= *iter;
	return (*temp).nodeAddress;
	
}


void Ant::deleteCycleNode(const int node)
{
	vector<antStackEntry*>::iterator iter;
	antStackEntry *temp;

	for(iter = cycleNodes.begin(); iter != cycleNodes.end(); ++iter)
	{
		temp = *iter;
		if( (*temp).nodeAddress == node)
		{
			break;
		}
	} //endfor

	if(iter != cycleNodes.end())
	{
		delete temp;
		cycleNodes.erase(iter);
	}
}

double Ant::nodeEntryTime(const int node, int myAddress)
{
	vector<antStackEntry*>::iterator iter;
	double nodeEntryTime = 0.0;


	for(iter = cycleNodes.begin(); iter != cycleNodes.end(); ++iter)
	{
		antStackEntry *temp = *iter;
		if( (*temp).nodeAddress == node)
		{
			nodeEntryTime = (*temp).nodeEntranceTime;
			break;
		}
	} //endfor

	if( iter!= cycleNodes.end())
	{
		return nodeEntryTime;
	}
	else
	{
		throw new cException(" Node Entry for %d not found in Vector at node %d",  
						node,myAddress);	

	}
}

vector<antStackEntry*>::iterator Ant::currentNodeIter(const int node)
{
	vector<antStackEntry*>::iterator iter;
	vector<antStackEntry*>::iterator tempIter;
	

	for(iter = cycleNodes.begin(); iter != cycleNodes.end(); ++iter)
	{
		antStackEntry *temp = *iter;
		if( (*temp).nodeAddress == node)
		{
			tempIter = iter;
			break;
		}
	} //endfor

	if( iter!= cycleNodes.end())
	{
		return tempIter;
	}
	else
	{
		throw new cException(" Iter Entry for %d not found in Vector", node);	

	}

}

vector<antStackEntry*>::iterator Ant::destNodeIter()
{
	return cycleNodes.end();
}

antStackEntry Ant::topOfStack()
{
	vector<antStackEntry*>::iterator iter;
	iter = cycleNodes.end();
	--iter; // to bring the iterator back to the last entry
	antStackEntry *temp = *iter;
	return (*temp);

}

int Ant::forwardAntSize()
{
	int nodesOnStack = cycleNodes.size();
	int size = (24 + 8 * nodesOnStack) * BYTE;
	return size;
}

int Ant::backwardAntSize(int size)
{
	int newSize = size - 8 * BYTE;
	return size;
}

int Ant::backwardAntSize()
{
	int nodesOnStack = cycleNodes.size();
	int size = (24 + 8 * nodesOnStack) * BYTE;
	return size;
}