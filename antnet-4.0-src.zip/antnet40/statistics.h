// -*- C++ -*-
// Copyright (C) 2003 Leherstuh f�r Betrieb System/ Verteilte System, 
// Universitaet Dortmund 
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// Author: Muddassar Farooq
// Informatik III, Universitaet Dortmund
// Germany

//-------------------------------------------------------------
// file: statisitics.h -- A Singleton Class for Global Statisitics
//        (part of AntNet Routing Simulation)
//-------------------------------------------------------------


#ifndef __STATISTICS_H
#define __STATISTICS_H

#include <vector>

#include <omnetpp.h>
#include <string.h>
#include <map>

using namespace std;

#define FILENAME 300

typedef struct
{
	double tPut;
	double pDelay;
	int i;
} throughputTimePair;

class statistics: public cSimpleModule
{
	public:
		void setFileName(const char* fName);

		void incrTotalBitsGenerated();
		void incrTotalDownBitsGenerated();
		void incrTotalBitsDelivered();
		void incrTotalBitsLost();
		void incrBitsGenerated(double bits);
		void incrBitsDelivered(double bits);
		void incrTotalBitsUndeliverable();

		void incrTotalAntsGenerated();
		void incrTotalAntsReceived();
		void incrTotalAntsDeleted();
		void incrTotalAntBits(double size);
		void incrTotalBandWidthInNetwork(double bandwidth);


		void incrEntriesInRoutingTable(int entries);
		void incrPacketInQueue(double lPacket);

		void insertQueueDelay(double qDelay);
		void insertPacketDelay(double pDelay);
		void insertThroughPutPacketDelay(double tPut, double tDelay,int time);
		void calculateThroughPutPacketDelay(int time);
		void incrNumHops(int nHops);
		void incrAntHops(int aHops);
		void insertAntLife(double lValue);
		double ninteythPercentile(cStdDev tVal);

		void incrAntsProcessed();

		void showStatistics();

		statistics(const char *name, cModule *parentmodule,	unsigned stacksize = 0);
		virtual ~statistics();

		virtual void initialize();
		virtual void finish();


	private:
		char sFileName[FILENAME];
		map<int,pair<double,double>*> tPutMap;
		
		double totalBitsGenerated;
		double totalBitsDelivered;
		double totalDownBitsGenerated;
		double totalBitsLost;
		double totalBitsUnDelivered;
		double bitsGenerated;
		double bitsDelivered;
		double entriesInRoutingTable;
		double totalBandWidth;

		double eHopsEntries;
		double hops;
		double antHops;
		double aEntries;
		double hEntries;
		

		double totalAntsGenerated;
		double totalAntsDelivered;
		double totalAntsDeleted;
		double totalAntsBitsOnNetwork;

		double queueDelay;
		double qEntries;

		double packetDelay;
		double pEntries;


		double packetsInQueue;
		double dEntries;
		double antsProcessed;

		int numStations;
		int i;
		int simTime;

		FILE *sFile;
		cStdDev pDelay;
		cStdDev antLife;
};

#endif